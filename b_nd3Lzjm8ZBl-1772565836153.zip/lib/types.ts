export interface Product {
  id: string
  name: string
  slug: string
  description: string
  shortDescription: string
  price: number
  originalPrice?: number
  discount?: number
  images: string[]
  category: string
  brand: string
  specs: Record<string, string>
  rating: number
  reviewCount: number
  stock: number
  featured: boolean
  createdAt: string
}

export interface CartItem {
  productId: string
  name: string
  price: number
  image: string
  quantity: number
}

export interface User {
  id: string
  name: string
  email: string
  role: "customer" | "admin"
  createdAt: string
}

export interface Order {
  id: string
  userId: string
  items: OrderItem[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  shippingAddress: ShippingAddress
  createdAt: string
}

export interface OrderItem {
  productId: string
  name: string
  price: number
  quantity: number
  image: string
}

export interface ShippingAddress {
  fullName: string
  address: string
  city: string
  state: string
  zipCode: string
  country: string
  phone: string
}

export interface Review {
  id: string
  productId: string
  userId: string
  userName: string
  rating: number
  comment: string
  createdAt: string
}

export type Category = {
  id: string
  name: string
  slug: string
  description: string
  icon: string
  productCount: number
}

export type SortOption = "relevance" | "price-asc" | "price-desc" | "rating" | "newest"

export interface ProductFilters {
  category?: string
  brand?: string
  minPrice?: number
  maxPrice?: number
  minRating?: number
  search?: string
  sort?: SortOption
  page?: number
  limit?: number
}
