"use client"

import { useEffect, useState } from "react"
import useSWR from "swr"
import {
  Package,
  Users,
  DollarSign,
  TrendingUp,
  ShoppingCart,
  BarChart3,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { useAuthStore } from "@/store/auth-store"
import { PRODUCTS_DATA } from "@/lib/products-data"
import { CATEGORIES } from "@/lib/constants"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import type { Product } from "@/lib/types"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

function StatCard({
  title,
  value,
  description,
  icon: Icon,
}: {
  title: string
  value: string
  description: string
  icon: React.ElementType
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-foreground">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}

export default function AdminPage() {
  const { user } = useAuthStore()
  const { data: authData } = useSWR("/api/auth/me", fetcher)
  const { setUser } = useAuthStore()
  const [products] = useState<Product[]>(PRODUCTS_DATA)

  useEffect(() => {
    if (authData?.user) {
      setUser(authData.user)
    }
  }, [authData, setUser])

  // Calculate stats from products data
  const totalProducts = products.length
  const totalStock = products.reduce((sum, p) => sum + p.stock, 0)
  const avgPrice =
    products.reduce((sum, p) => sum + p.price, 0) / totalProducts
  const featuredCount = products.filter((p) => p.featured).length

  const categoryCounts = CATEGORIES.map((cat) => ({
    ...cat,
    count: products.filter((p) => p.category === cat.id).length,
  }))

  // Not authenticated or not admin - show demo mode
  const isAdmin = user?.role === "admin"

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Panel Admin</h1>
          <p className="mt-1 text-muted-foreground">
            Vista general de la tienda
          </p>
        </div>
        {!isAdmin && (
          <Badge variant="secondary" className="text-xs">
            Modo de demostracion
          </Badge>
        )}
      </div>

      {/* Stats grid */}
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total productos"
          value={totalProducts.toString()}
          description={`${featuredCount} destacados`}
          icon={Package}
        />
        <StatCard
          title="Stock total"
          value={totalStock.toLocaleString()}
          description="Unidades en inventario"
          icon={ShoppingCart}
        />
        <StatCard
          title="Precio promedio"
          value={`$${avgPrice.toLocaleString(undefined, {
            maximumFractionDigits: 0,
          })}`}
          description="Precio medio del catalogo"
          icon={DollarSign}
        />
        <StatCard
          title="Categorias"
          value={CATEGORIES.length.toString()}
          description="Categorias activas"
          icon={BarChart3}
        />
      </div>

      {/* Categories breakdown */}
      <div className="mb-8 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-primary" />
              Productos por categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {categoryCounts.map((cat) => (
                <div
                  key={cat.id}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm font-medium text-foreground">
                    {cat.name}
                  </span>
                  <div className="flex items-center gap-3">
                    <div className="h-2 w-24 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-primary"
                        style={{
                          width: `${(cat.count / totalProducts) * 100}%`,
                        }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground w-6 text-right">
                      {cat.count}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Users className="h-5 w-5 text-primary" />
              Productos destacados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {products
                .filter((p) => p.featured)
                .slice(0, 6)
                .map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between"
                  >
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-foreground line-clamp-1">
                        {product.name}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {product.brand} - Stock: {product.stock}
                      </span>
                    </div>
                    <span className="text-sm font-medium text-foreground">
                      ${product.price.toLocaleString()}
                    </span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Inventario de productos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="pb-3 text-left font-medium text-muted-foreground">
                    Producto
                  </th>
                  <th className="pb-3 text-left font-medium text-muted-foreground">
                    Categoria
                  </th>
                  <th className="pb-3 text-left font-medium text-muted-foreground">
                    Precio
                  </th>
                  <th className="pb-3 text-left font-medium text-muted-foreground">
                    Stock
                  </th>
                  <th className="pb-3 text-left font-medium text-muted-foreground">
                    Rating
                  </th>
                </tr>
              </thead>
              <tbody>
                {products.slice(0, 15).map((product) => (
                  <tr key={product.id} className="border-b border-border/50">
                    <td className="py-3">
                      <div className="flex flex-col">
                        <span className="font-medium text-foreground line-clamp-1">
                          {product.name}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {product.brand}
                        </span>
                      </div>
                    </td>
                    <td className="py-3">
                      <Badge variant="secondary" className="capitalize text-xs">
                        {product.category}
                      </Badge>
                    </td>
                    <td className="py-3 font-medium text-foreground">
                      ${product.price.toLocaleString()}
                    </td>
                    <td className="py-3">
                      <span
                        className={`font-medium ${
                          product.stock < 20
                            ? "text-destructive"
                            : "text-foreground"
                        }`}
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="py-3 text-foreground">{product.rating}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="mt-6 flex justify-center">
        <Button asChild variant="outline">
          <Link href="/catalogo">Ver catalogo completo</Link>
        </Button>
      </div>
    </div>
  )
}
