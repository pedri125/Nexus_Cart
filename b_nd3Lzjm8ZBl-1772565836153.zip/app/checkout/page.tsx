"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { CheckCircle, CreditCard, Truck, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useCartStore } from "@/store/cart-store"
import { toast } from "sonner"
import Link from "next/link"

export default function CheckoutPage() {
  const router = useRouter()
  const { items, getTotal, clearCart } = useCartStore()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)

  const total = getTotal()
  const shipping = total >= 99 ? 0 : 9.99
  const tax = total * 0.16
  const grandTotal = total + shipping + tax

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simular procesamiento
    await new Promise((r) => setTimeout(r, 2000))

    clearCart()
    setOrderComplete(true)
    toast.success("Pedido realizado con exito")
    setIsSubmitting(false)
  }

  if (orderComplete) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center justify-center gap-6 px-4 py-20 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
          <CheckCircle className="h-10 w-10 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">
          Pedido confirmado
        </h1>
        <p className="text-muted-foreground leading-relaxed">
          Tu pedido ha sido procesado exitosamente. Recibiras un correo de
          confirmacion con los detalles del envio.
        </p>
        <p className="text-sm font-medium text-foreground">
          Orden #NX-{Math.random().toString(36).substring(2, 8).toUpperCase()}
        </p>
        <Button asChild>
          <Link href="/catalogo">Seguir comprando</Link>
        </Button>
      </div>
    )
  }

  if (items.length === 0) {
    router.push("/carrito")
    return null
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
      <Link
        href="/carrito"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Volver al carrito
      </Link>

      <h1 className="mb-8 text-3xl font-bold text-foreground">Checkout</h1>

      <form onSubmit={handleSubmit}>
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Form */}
          <div className="flex flex-col gap-8 lg:col-span-2">
            {/* Shipping info */}
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="mb-4 flex items-center gap-2">
                <Truck className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">
                  Datos de envio
                </h2>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="fullName">Nombre completo</Label>
                  <Input
                    id="fullName"
                    placeholder="Juan Garcia Lopez"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="email">Correo electronico</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="juan@ejemplo.com"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address">Direccion</Label>
                  <Input
                    id="address"
                    placeholder="Calle Principal 123, Col. Centro"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="city">Ciudad</Label>
                  <Input
                    id="city"
                    placeholder="Ciudad de Mexico"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="state">Estado</Label>
                  <Input
                    id="state"
                    placeholder="CDMX"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="zip">Codigo postal</Label>
                  <Input
                    id="zip"
                    placeholder="06600"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Telefono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+52 55 1234 5678"
                    required
                    className="mt-1.5"
                  />
                </div>
              </div>
            </div>

            {/* Payment info */}
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="mb-4 flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold text-foreground">
                  Datos de pago
                </h2>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="cardName">Nombre en la tarjeta</Label>
                  <Input
                    id="cardName"
                    placeholder="Juan Garcia Lopez"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="cardNumber">Numero de tarjeta</Label>
                  <Input
                    id="cardNumber"
                    placeholder="4242 4242 4242 4242"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="expiry">Fecha de expiracion</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/AA"
                    required
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    required
                    className="mt-1.5"
                  />
                </div>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                Este es un checkout de demostracion. No se procesan pagos reales.
              </p>
            </div>
          </div>

          {/* Order summary */}
          <div className="h-fit rounded-xl border border-border bg-card p-6">
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              Tu pedido
            </h2>
            <div className="flex flex-col gap-3">
              {items.map((item) => (
                <div key={item.productId} className="flex items-center gap-3">
                  <div className="relative h-12 w-12 flex-shrink-0 overflow-hidden rounded-lg bg-muted">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="48px"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground line-clamp-1">
                      {item.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      x{item.quantity}
                    </p>
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    ${(item.price * item.quantity).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
            <Separator className="my-4" />
            <div className="flex flex-col gap-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">
                  ${total.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                  })}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Envio</span>
                <span className="text-foreground">
                  {shipping === 0 ? "Gratis" : `$${shipping.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">IVA (16%)</span>
                <span className="text-foreground">
                  ${tax.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                  })}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold">
                <span className="text-foreground">Total</span>
                <span className="text-foreground">
                  ${grandTotal.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                  })}
                </span>
              </div>
            </div>
            <Button
              type="submit"
              className="mt-6 w-full"
              size="lg"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Procesando..." : `Pagar $${grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
