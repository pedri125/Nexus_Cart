import { NextResponse } from "next/server"
import { hash } from "bcryptjs"
import { Redis } from "@upstash/redis"
import { createToken, setSession } from "@/lib/auth"

const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!,
})

export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "Todos los campos son requeridos" },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: "La contrasena debe tener al menos 6 caracteres" },
        { status: 400 }
      )
    }

    // Check if user exists
    const existing = await redis.get(`user:email:${email.toLowerCase()}`)
    if (existing) {
      return NextResponse.json(
        { error: "El correo ya esta registrado" },
        { status: 409 }
      )
    }

    const userId = `user-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`
    const hashedPassword = await hash(password, 12)

    const user = {
      id: userId,
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      role: "customer" as const,
      createdAt: new Date().toISOString(),
    }

    // Store user
    await redis.set(`user:${userId}`, JSON.stringify(user))
    await redis.set(`user:email:${email.toLowerCase()}`, userId)

    // Create session
    const token = await createToken({ userId, role: "customer" })
    await setSession(token)

    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json(
      { error: "Error al registrar usuario" },
      { status: 500 }
    )
  }
}
