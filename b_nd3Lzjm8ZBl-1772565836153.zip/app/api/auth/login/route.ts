import { NextResponse } from "next/server"
import { compare } from "bcryptjs"
import { Redis } from "@upstash/redis"
import { createToken, setSession } from "@/lib/auth"

const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!,
})

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error: "Todos los campos son requeridos" },
        { status: 400 }
      )
    }

    // Find user by email
    const userId = await redis.get<string>(`user:email:${email.toLowerCase()}`)
    if (!userId) {
      return NextResponse.json(
        { error: "Credenciales invalidas" },
        { status: 401 }
      )
    }

    const userData = await redis.get<string>(`user:${userId}`)
    if (!userData) {
      return NextResponse.json(
        { error: "Credenciales invalidas" },
        { status: 401 }
      )
    }

    const user = typeof userData === "string" ? JSON.parse(userData) : userData

    // Verify password
    const isValid = await compare(password, user.password)
    if (!isValid) {
      return NextResponse.json(
        { error: "Credenciales invalidas" },
        { status: 401 }
      )
    }

    // Create session
    const token = await createToken({ userId: user.id, role: user.role })
    await setSession(token)

    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json(
      { error: "Error al iniciar sesion" },
      { status: 500 }
    )
  }
}
