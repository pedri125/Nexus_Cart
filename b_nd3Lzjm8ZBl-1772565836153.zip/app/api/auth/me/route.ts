import { NextResponse } from "next/server"
import { Redis } from "@upstash/redis"
import { getSession } from "@/lib/auth"

const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!,
})

export async function GET() {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ user: null })
    }

    const userData = await redis.get<string>(`user:${session.userId}`)
    if (!userData) {
      return NextResponse.json({ user: null })
    }

    const user = typeof userData === "string" ? JSON.parse(userData) : userData
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({ user: userWithoutPassword })
  } catch {
    return NextResponse.json({ user: null })
  }
}
