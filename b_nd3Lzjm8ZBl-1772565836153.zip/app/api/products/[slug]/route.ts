import { NextResponse } from "next/server"
import { PRODUCTS_DATA } from "@/lib/products-data"

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params

  const product = PRODUCTS_DATA.find((p) => p.slug === slug)

  if (!product) {
    return NextResponse.json({ error: "Producto no encontrado" }, { status: 404 })
  }

  return NextResponse.json(product)
}
