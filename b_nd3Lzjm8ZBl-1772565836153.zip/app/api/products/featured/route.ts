import { NextResponse } from "next/server"
import { PRODUCTS_DATA } from "@/lib/products-data"

export async function GET() {
  const featured = PRODUCTS_DATA.filter((p) => p.featured)
  return NextResponse.json(featured)
}
