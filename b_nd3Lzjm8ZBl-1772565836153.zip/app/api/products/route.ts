import { NextResponse } from "next/server"
import { PRODUCTS_DATA } from "@/lib/products-data"
import type { ProductFilters } from "@/lib/types"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)

  const filters: ProductFilters = {
    category: searchParams.get("category") || undefined,
    brand: searchParams.get("brand") || undefined,
    minPrice: searchParams.get("minPrice")
      ? Number(searchParams.get("minPrice"))
      : undefined,
    maxPrice: searchParams.get("maxPrice")
      ? Number(searchParams.get("maxPrice"))
      : undefined,
    minRating: searchParams.get("minRating")
      ? Number(searchParams.get("minRating"))
      : undefined,
    search: searchParams.get("search") || undefined,
    sort: (searchParams.get("sort") as ProductFilters["sort"]) || "relevance",
    page: Number(searchParams.get("page")) || 1,
    limit: Number(searchParams.get("limit")) || 12,
  }

  let products = [...PRODUCTS_DATA]

  // Filter by category
  if (filters.category) {
    products = products.filter((p) => p.category === filters.category)
  }

  // Filter by brand
  if (filters.brand) {
    products = products.filter((p) => p.brand === filters.brand)
  }

  // Filter by price range
  if (filters.minPrice !== undefined) {
    products = products.filter((p) => p.price >= filters.minPrice!)
  }
  if (filters.maxPrice !== undefined) {
    products = products.filter((p) => p.price <= filters.maxPrice!)
  }

  // Filter by rating
  if (filters.minRating !== undefined) {
    products = products.filter((p) => p.rating >= filters.minRating!)
  }

  // Search by name or description
  if (filters.search) {
    const query = filters.search.toLowerCase()
    products = products.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query)
    )
  }

  // Sort
  switch (filters.sort) {
    case "price-asc":
      products.sort((a, b) => a.price - b.price)
      break
    case "price-desc":
      products.sort((a, b) => b.price - a.price)
      break
    case "rating":
      products.sort((a, b) => b.rating - a.rating)
      break
    case "newest":
      products.sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      break
    default:
      // relevance: featured first, then by rating
      products.sort((a, b) => {
        if (a.featured && !b.featured) return -1
        if (!a.featured && b.featured) return 1
        return b.rating - a.rating
      })
  }

  // Pagination
  const total = products.length
  const page = filters.page || 1
  const limit = filters.limit || 12
  const start = (page - 1) * limit
  const paginatedProducts = products.slice(start, start + limit)

  return NextResponse.json({
    products: paginatedProducts,
    total,
    page,
    limit,
    totalPages: Math.ceil(total / limit),
  })
}
